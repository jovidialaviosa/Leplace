const mongoose = require('mongoose')
const bcrypt = require('bcryptjs')
const HASH_ROUND = 10


let dosenSchema = mongoose.Schema({
    nama_lengkap:{
        type: String,
        require:[true, 'nama lengkap harus diisi']
    },
    email:{
        type:String,
        require:[true, 'email harus diisi']
    },
    password:{
        type: String,
        require:[true, 'kata sandi harus diisi']
    },
})

dosenSchema.pre('save', function (next){
    this.password = bcrypt.hashSync(this.password, HASH_ROUND)
    next()
})

module.exports = mongoose.model('Dosen', dosenSchema)

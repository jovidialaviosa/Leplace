const Dosen = require('./model')
module.exports={
    view_login: async(req, res)=>{
        try {
            res.render('auth/login')
        } catch (err) {
            console.log(err)
        }
    },
    view_signup_dosen: async(req, res)=>{
        try {
            res.render('auth/signup')
        } catch (err) {
            console.log(err)
        }
    },
    action_signup_dosen: async(req, res)=>{
        try {
           const payload = req.body
           const dosen = new Dosen(payload)
           await dosen.save()
           delete dosen._doc.password
           res.status(201).json({
                data: dosen
           })
        }catch (err) {
            console.log(err)
        }
    }
}
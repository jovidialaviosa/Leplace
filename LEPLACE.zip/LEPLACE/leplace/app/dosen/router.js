var express = require('express');
var router = express.Router();
const {view_login, view_signup_dosen, action_signup_dosen, } = require('./controller');

/* GET home page. */
router.get('/', view_login);
router.get('/signup_dosen', view_signup_dosen);
router.post('/signup_dosen', action_signup_dosen);

module.exports = router;

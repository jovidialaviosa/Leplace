var express = require('express');
var router = express.Router();
const {view_login, view_signup, action_signup} = require('./controller');

/* GET home page. */
router.get('/', view_login);
router.get('/signup', view_signup);
router.post('/signup', action_signup);

module.exports = router;

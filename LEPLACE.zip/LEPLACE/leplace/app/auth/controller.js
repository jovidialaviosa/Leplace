const Mahasiswa = require('./model')
module.exports={
    view_login: async(req, res)=>{
        try {
            res.render('auth/login')
        } catch (err) {
            console.log(err)
        }
    },
    view_signup: async(req, res)=>{
        try {
            res.render('auth/signup')
        } catch (err) {
            console.log(err)
        }
    },
    action_signup: async(req, res)=>{
        try {
           const payload = req.body
           const mahasiswa = new Mahasiswa(payload)
           await mahasiswa.save()
           delete mahasiswa._doc.password
           res.status(201).json({
                data: mahasiswa
           })
        }catch (err) {
            console.log(err)
        }
    }
}
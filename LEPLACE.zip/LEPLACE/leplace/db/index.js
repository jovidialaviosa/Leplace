const mongoose = require('mongoose')
const {urlDb} = require('../config')
mongoose.connect('mongodb://127.0.0.1:27017/leplace_db')

const db = mongoose.connection;

module.exports = db